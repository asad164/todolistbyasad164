from django.shortcuts import render, HttpResponseRedirect
from .forms import StudentForm
from .models import StudentRegistraion, StudentSecond
# Create your views here.


def register(request):
    if request.method == 'POST':
        fm = StudentForm(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            rl = fm.cleaned_data['roll']
            dt = fm.cleaned_data['date_log']
            reg = StudentRegistraion(name=nm, roll=rl, date_joined = dt)
            reg.save()
    else:
        fm = StudentForm()
    return render(request, 'htmlatdate/student.html', {'form':fm})


def new_student(request):
    if request.method == 'POST':
        nm = request.POST['name']
        rl = request.POST['number']
        dt = request.POST['date_created']
        reg = StudentSecond(name=nm, roll=rl, date_joined = dt)
        reg.save()
        return HttpResponseRedirect('/')
    else:
        return render(request, 'htmlatdate/newstudent.html')
