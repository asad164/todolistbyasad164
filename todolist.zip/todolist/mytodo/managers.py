import datetime
from django.db import models


class CutomManager(models.Manager):
    def get_today_list(self):
        current_date = datetime.datetime.today()
        return super().get_queryset().filter(list_date=current_date)

    def get_next_day_list(self):
        next_day_date = datetime.datetime.today() + datetime.timedelta(days=1)
        return super().get_queryset().filter(list_date=next_day_date)







