from django.db import models
from .managers import CutomManager

# Create your models here.

class TodoModel(models.Model):
    content= models.CharField(max_length=200)
    list_date = models.DateField()

    objects = models.Manager()
    todolist = CutomManager()




