from django.db import models

# Create your models here.

class StudentRegistraion(models.Model):
    name = models.CharField(max_length=200)
    roll = models.IntegerField()
    date_joined = models.DateField()


class StudentSecond(models.Model):
    name = models.CharField(max_length=200)
    roll = models.IntegerField()
    date_joined = models.DateField()