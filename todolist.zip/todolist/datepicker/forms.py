from django import forms
from .models import DateModel
from django.forms import ModelForm
import datetime
from django.forms.widgets import DateInput



class DateForm(forms.ModelForm):
    class Meta:
        model = DateModel
        fields = ['title', 'content', 'list_date']
        widgets = {
            'list_date': DateInput(attrs={'type': 'date'}),
        }



