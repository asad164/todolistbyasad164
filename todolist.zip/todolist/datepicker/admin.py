from django.contrib import admin
from .models import DateModel
# Register your models here.
@admin.register(DateModel)
class DateAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'content', 'list_date']