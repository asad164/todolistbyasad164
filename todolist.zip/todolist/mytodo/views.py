from django.shortcuts import render, HttpResponseRedirect
from .models import TodoModel
from .forms import TodoForm
import datetime
from .managers import CutomManager
from django.db.models import Count
# Create your views here.

def home(request):

    if request.method == 'POST':
        fm = TodoForm(request.POST)
        if fm.is_valid():
            fm.save()
        fm= TodoForm()
    else:
        fm = TodoForm()

    current_date = datetime.datetime.today()
    nexday_date =  datetime.datetime.today() + datetime.timedelta(days=1)

    #my_list = TodoModel.objects.filter(list_date = current_date)
    #nextday_list = TodoModel.objects.filter(list_date = nexday_date)

    my_list = TodoModel.todolist.get_today_list()
    nextday_list = TodoModel.todolist.get_next_day_list()

    return render(request, 'mytodo/home.html', {'form':fm, 'my_list':my_list, 'nextday_list':nextday_list,
                                                'current_date':current_date, 'nextday_date':nexday_date
                                                })


def delete_todo_list(request, id):

    pi = TodoModel.objects.get(pk=id)
    pi.delete()
    return HttpResponseRedirect('/')

