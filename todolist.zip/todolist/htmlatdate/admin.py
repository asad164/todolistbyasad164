from django.contrib import admin
from .models import StudentRegistraion, StudentSecond
# Register your models here.

@admin.register(StudentRegistraion)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'roll', 'date_joined']


@admin.register(StudentSecond)
class StudentsAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'roll', 'date_joined']