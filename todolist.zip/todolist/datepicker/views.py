from django.shortcuts import render
from .models import DateModel
from .forms import DateForm
import datetime
# Create your views here.
def home_date(request):

    if request.method == 'POST':
        fm = DateForm(request.POST)
        if fm.is_valid():
            fm.save()
        fm= DateForm()
    else:
        fm = DateForm()
    current_date = datetime.datetime.today()
    nexday_date =  datetime.datetime.today() + datetime.timedelta(days=1)

    my_list = DateModel.objects.filter(list_date = current_date)
    nextday_list = DateModel.objects.filter(list_date = nexday_date)




    return render(request, 'datepicker/home.html', {'form':fm, 'my_list':my_list, 'nextday_list':nextday_list })