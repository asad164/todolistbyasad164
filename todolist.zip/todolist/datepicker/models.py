from django.db import models

# Create your models here.
class DateModel(models.Model):
    title = models.CharField(max_length=100)
    content= models.TextField(max_length=1000)
    list_date = models.DateField()